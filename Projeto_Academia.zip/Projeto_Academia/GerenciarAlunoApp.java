package Projeto_Academia;

import javax.swing.*;
import java.awt.*;

public class GerenciarAlunoApp extends JFrame {
    public GerenciarAlunoApp() {
        setTitle("Gerenciar Alunos");
        setSize(400, 300);
        setLayout(new GridLayout(5, 2));

        JTextField cpfField = new JTextField();
        JTextField nomeField = new JTextField();
        JTextField idadeField = new JTextField();

        JButton buscarButton = new JButton("Buscar");
        JButton atualizarButton = new JButton("Atualizar");
        JButton excluirButton = new JButton("Excluir");

        add(new JLabel("CPF:"));
        add(cpfField);
        add(new JLabel("Nome:"));
        add(nomeField);
        add(new JLabel("Idade:"));
        add(idadeField);
        add(buscarButton);
        add(atualizarButton);
        add(excluirButton);

        buscarButton.addActionListener(e -> {
            AlunoAcademia aluno = ConsultaAdm.buscarAlunoPorCpf(cpfField.getText());
            if (aluno != null) {
                nomeField.setText(aluno.getNome());
                idadeField.setText(String.valueOf(aluno.getIdade()));
            } else {
                JOptionPane.showMessageDialog(this, "Aluno não encontrado.");
            }
        });

        atualizarButton.addActionListener(e -> {
            AlunoAcademia aluno = ConsultaAdm.buscarAlunoPorCpf(cpfField.getText());
            if (aluno != null) {
                aluno.setNome(nomeField.getText());
                aluno.setIdade(Integer.parseInt(idadeField.getText()));
                ConsultaAdm.salvarDados();
                JOptionPane.showMessageDialog(this, "Aluno atualizado com sucesso!");
            }
        });

        excluirButton.addActionListener(e -> {
            ConsultaAdm.removerAlunoPorCpf(cpfField.getText());
            nomeField.setText("");
            idadeField.setText("");
            cpfField.setText("");
            JOptionPane.showMessageDialog(this, "Aluno excluído com sucesso!");
        });

        setLocationRelativeTo(null);
        setVisible(true);
    }
}

