package Projeto_Academia;

/**
 * Exceção para alunos sem plano contratado.
 */
public class PlanoNaoEncontradoException extends Exception {
    public PlanoNaoEncontradoException(String msg) {
        super(msg);
    }
}

