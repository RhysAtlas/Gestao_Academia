package Projeto_Academia;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

// Interface gráfica que permite ao administrador/instrutor vincular plano e ficha ao aluno
public class CadastroPlanoFichaApp extends JFrame {
    private JTextField cpfField, nomePlanoField, precoPlanoField, objetivoField;
    private JTextArea descricaoArea;

    public CadastroPlanoFichaApp() {
        setTitle("Vincular Plano e Ficha ao Aluno");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);

        // Campos de entrada para CPF, plano e ficha
        JLabel cpfLabel = new JLabel("CPF do Aluno:");
        cpfLabel.setBounds(20, 20, 120, 25);
        add(cpfLabel);

        cpfField = new JTextField();
        cpfField.setBounds(150, 20, 200, 25);
        add(cpfField);

        JLabel nomePlanoLabel = new JLabel("Nome do Plano:");
        nomePlanoLabel.setBounds(20, 60, 120, 25);
        add(nomePlanoLabel);

        nomePlanoField = new JTextField();
        nomePlanoField.setBounds(150, 60, 200, 25);
        add(nomePlanoField);

        JLabel precoLabel = new JLabel("Preço:");
        precoLabel.setBounds(20, 100, 120, 25);
        add(precoLabel);

        precoPlanoField = new JTextField();
        precoPlanoField.setBounds(150, 100, 200, 25);
        add(precoPlanoField);

        JLabel objetivoLabel = new JLabel("Objetivo:");
        objetivoLabel.setBounds(20, 140, 120, 25);
        add(objetivoLabel);

        objetivoField = new JTextField();
        objetivoField.setBounds(150, 140, 200, 25);
        add(objetivoField);

        JLabel descricaoLabel = new JLabel("Descrição:");
        descricaoLabel.setBounds(20, 180, 120, 25);
        add(descricaoLabel);

        descricaoArea = new JTextArea();
        descricaoArea.setBounds(150, 180, 200, 100);
        add(descricaoArea);

        JButton vincularButton = new JButton("Vincular");
        vincularButton.setBounds(130, 300, 120, 30);
        add(vincularButton);

        // Ao clicar em "Vincular", os dados são aplicados ao aluno
        vincularButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String cpf = cpfField.getText();
                AlunoAcademia aluno = ConsultaAdm.buscarAlunoPorCpf(cpf);
                if (aluno != null) {
                    try {
                        String nomePlano = nomePlanoField.getText();
                        double preco = Double.parseDouble(precoPlanoField.getText());
                        Plano plano = new Plano(nomePlano, preco);

                        String objetivo = objetivoField.getText();
                        String descricao = descricaoArea.getText();
                        FichaTreino ficha = new FichaTreino(objetivo, descricao);

                        aluno.contratarPlano(plano);
                        aluno.cadastrarFicha(ficha);

                        ConsultaAdm.salvarDados();

                        JOptionPane.showMessageDialog(null, "Plano e Ficha vinculados com sucesso!");
                        dispose();
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(null, "Preço inválido.");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Aluno não encontrado.");
                }
            }
        });

        setVisible(true);
    }
}

