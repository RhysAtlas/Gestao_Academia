package Projeto_Academia;

import Projeto_Academia.FichaTreino;
import Projeto_Academia.Plano;

import java.io.Serializable;

// Classe modelo que representa o aluno da academia
public class AlunoAcademia implements Serializable {
    private String nome;
    private int idade;
    private String cpf;
    private Plano plano;
    private FichaTreino ficha;

    public AlunoAcademia(String nome, int idade, String cpf) {
        this.nome = nome;
        this.idade = idade;
        this.cpf = cpf;
    }

    // Getters
    public String getNome() { return nome; }
    public int getIdade() { return idade; }
    public String getCpf() { return cpf; }
    public Plano getPlano() { return plano; }
    public FichaTreino getFicha() { return ficha; }

    // Setters
    public void setNome(String nome) { this.nome = nome; }
    public void setIdade(int idade) { this.idade = idade; }

    // Métodos para associar plano e ficha
    public void contratarPlano(Plano plano) {
        this.plano = plano;
    }

    public void cadastrarFicha(FichaTreino ficha) {
        this.ficha = ficha;
    }
}

