package Projeto_Academia;

import javax.swing.*;
import java.awt.*;

public class CadastroAlunoApp extends JFrame {
    public CadastroAlunoApp() {
        setTitle("Cadastro de Aluno");
        setSize(300, 200);
        setLayout(new GridLayout(4, 2));

        JTextField nomeField = new JTextField();
        JTextField idadeField = new JTextField();
        JTextField cpfField = new JTextField();
        JButton cadastrarButton = new JButton("Cadastrar");

        add(new JLabel("Nome:"));
        add(nomeField);
        add(new JLabel("Idade:"));
        add(idadeField);
        add(new JLabel("CPF:"));
        add(cpfField);
        add(new JLabel());
        add(cadastrarButton);

        cadastrarButton.addActionListener(e -> {
            String nome = nomeField.getText();
            int idade = Integer.parseInt(idadeField.getText());
            String cpf = cpfField.getText();
            if (ConsultaAdm.buscarAlunoPorCpf(cpf) != null) {
                JOptionPane.showMessageDialog(this, "Já existe um aluno com esse CPF.");
            } else {
                AlunoAcademia aluno = new AlunoAcademia(nome, idade, cpf);
                ConsultaAdm.adicionarAluno(aluno);
                JOptionPane.showMessageDialog(this, "Aluno cadastrado com sucesso!");
                dispose();
            }
        });

        setLocationRelativeTo(null);
        setVisible(true);
    }
}