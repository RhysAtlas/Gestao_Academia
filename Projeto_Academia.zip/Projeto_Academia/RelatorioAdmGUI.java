package Projeto_Academia;

import javax.swing.*;
import java.util.List;

public class RelatorioAdmGUI extends JFrame {
    private JTextArea relatorioArea;

    public RelatorioAdmGUI() {
        setTitle("Relatório de Alunos e Planos");
        setSize(450, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);

        relatorioArea = new JTextArea();
        relatorioArea.setEditable(false);

        JScrollPane scroll = new JScrollPane(relatorioArea);
        scroll.setBounds(20, 20, 400, 320);
        add(scroll);

        preencherRelatorio();

        setVisible(true);
    }

    private void preencherRelatorio() {
        List<AlunoAcademia> alunos = ConsultaAdm.getAlunos();
        if (alunos.isEmpty()) {
            relatorioArea.setText("Nenhum aluno cadastrado.");
        } else {
            StringBuilder sb = new StringBuilder();
            for (AlunoAcademia aluno : alunos) {
                sb.append("Nome: ").append(aluno.getNome()).append("\n");
                sb.append("CPF: ").append(aluno.getCpf()).append("\n");

                if (aluno.getPlano() != null)
                    sb.append("Plano: ").append(aluno.getPlano().getNome()).append(" - R$").append(aluno.getPlano().getPreco()).append("\n");
                else
                    sb.append("Plano: Nenhum\n");

                if (aluno.getFicha() != null)
                    sb.append("Ficha: ").append(aluno.getFicha().getObjetivo()).append(" - ").append(aluno.getFicha().getDescricao()).append("\n");
                else
                    sb.append("Ficha: Nenhuma\n");

                sb.append("-----------\n");
            }
            relatorioArea.setText(sb.toString());
        }
    }
}
