package Projeto_Academia;

import java.io.Serializable;
/**
 * Representa um plano da academia.
 */

public class Plano implements Serializable {
    private String nome;
    private double preco;

    public Plano(String nome, double preco) {
        this.nome = nome;
        this.preco = preco;
    }

    public String getNome() { return nome; }
    public double getPreco() { return preco; }

    // Retorna o plano em formato legível
    @Override
    public String toString() {
        return nome + " (R$ " + preco + ")";
    }
}

