package Projeto_Academia;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SistemaAcademia extends JFrame {
    public SistemaAcademia() {
        setTitle("Sistema de Gestão de Academia");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);

        JButton cadastroAlunoBtn = new JButton("Cadastrar Aluno");
        cadastroAlunoBtn.setBounds(100, 30, 200, 40);
        add(cadastroAlunoBtn);

        JButton gerenciarAlunoBtn = new JButton("Gerenciar Alunos");
        gerenciarAlunoBtn.setBounds(100, 80, 200, 40);
        add(gerenciarAlunoBtn);

        JButton vincularPlanoFichaBtn = new JButton("Vincular Plano/Ficha");
        vincularPlanoFichaBtn.setBounds(100, 130, 200, 40);
        add(vincularPlanoFichaBtn);

        JButton consultaAlunoBtn = new JButton("Consulta de Aluno");
        consultaAlunoBtn.setBounds(100, 180, 200, 40);
        add(consultaAlunoBtn);

        JButton relatorioBtn = new JButton("Relatório Geral");
        relatorioBtn.setBounds(100, 230, 200, 40);
        add(relatorioBtn);

        JButton sairBtn = new JButton("Sair");
        sairBtn.setBounds(100, 280, 200, 40);
        add(sairBtn);

        // Ações dos botões
        cadastroAlunoBtn.addActionListener(e -> new CadastroAlunoApp());
        gerenciarAlunoBtn.addActionListener(e -> new GerenciarAlunoApp());
        vincularPlanoFichaBtn.addActionListener(e -> new CadastroPlanoFichaApp());
        consultaAlunoBtn.addActionListener(e -> new ConsultaAlunoGUI());
        relatorioBtn.addActionListener(e -> new RelatorioAdmGUI());
        sairBtn.addActionListener(e -> System.exit(0));

        setVisible(true);
    }

    public static void main(String[] args) {
        new SistemaAcademia();
    }
}
