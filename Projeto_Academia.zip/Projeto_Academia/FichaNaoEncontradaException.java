package Projeto_Academia;

/**
 * Exceção para alunos sem ficha cadastrada.
 */
public class FichaNaoEncontradaException extends Exception {
    public FichaNaoEncontradaException(String msg) {
        super(msg);
    }
}

