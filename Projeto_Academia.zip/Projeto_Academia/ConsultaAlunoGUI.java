package Projeto_Academia;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

// Interface gráfica para consultar um aluno pelo CPF e exibir seus dados, plano e ficha
public class ConsultaAlunoGUI extends JFrame {
    private JTextField cpfField;
    private JTextArea resultadoArea;

    public ConsultaAlunoGUI() {
        setTitle("Consulta de Aluno");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);

        JLabel cpfLabel = new JLabel("Digite o CPF:");
        cpfLabel.setBounds(20, 20, 100, 25);
        add(cpfLabel);

        cpfField = new JTextField();
        cpfField.setBounds(120, 20, 200, 25);
        add(cpfField);

        JButton consultarButton = new JButton("Consultar");
        consultarButton.setBounds(120, 60, 100, 25);
        add(consultarButton);

        resultadoArea = new JTextArea();
        resultadoArea.setEditable(false);
        JScrollPane scroll = new JScrollPane(resultadoArea);
        scroll.setBounds(20, 100, 350, 140);
        add(scroll);

        // Ação ao clicar no botão "Consultar"
        consultarButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String cpf = cpfField.getText();
                AlunoAcademia aluno = ConsultaAdm.buscarAlunoPorCpf(cpf);

                if (aluno != null) {
                    StringBuilder sb = new StringBuilder();
                    sb.append("Nome: ").append(aluno.getNome()).append("\n");
                    sb.append("Idade: ").append(aluno.getIdade()).append("\n");
                    sb.append("CPF: ").append(aluno.getCpf()).append("\n");

                    if (aluno.getPlano() != null) {
                        sb.append("Plano: ").append(aluno.getPlano()).append("\n");
                    } else {
                        sb.append("Plano: Nenhum vinculado\n");
                    }

                    if (aluno.getFicha() != null) {
                        sb.append("Ficha de Treino:\n").append(aluno.getFicha()).append("\n");
                    } else {
                        sb.append("Ficha de Treino: Nenhuma vinculada\n");
                    }

                    resultadoArea.setText(sb.toString());
                } else {
                    resultadoArea.setText("Aluno não encontrado.");
                }
            }
        });

        setVisible(true);
    }
}


