package Projeto_Academia;

import java.io.*;
import java.util.*;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

// Classe responsável por armazenar, consultar e manipular os dados dos alunos.
// Também cuida da persistência em arquivo (alunos.dat).
public class ConsultaAdm {
    private static List<AlunoAcademia> alunos = new ArrayList<>();
    private static final String ARQUIVO = "alunos.dat";

    static {
        carregarDados();
    }

    // Adiciona um novo aluno à lista e salva no arquivo
    public static void adicionarAluno(AlunoAcademia aluno) {
        alunos.add(aluno);
        salvarDados();
    }

    // Busca um aluno pelo CP
    public static AlunoAcademia buscarAlunoPorCpf(String cpf) {
        for (AlunoAcademia aluno : alunos) {
            if (aluno.getCpf().equals(cpf)) {
                return aluno;
            }
        }
        return null;
    }

    // Remove aluno se encontrado pelo CPF
    public static boolean removerAlunoPorCpf(String cpf) {
        AlunoAcademia aluno = buscarAlunoPorCpf(cpf);
        if (aluno != null) {
            alunos.remove(aluno);
            salvarDados();
            return true;
        }
        return false;
    }

    // Retorna a lista atual de alunos
    public static List<AlunoAcademia> getAlunos() {
        return alunos;
    }

    // Salva todos os dados no arquivo .dat
    public static void salvarDados() {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(ARQUIVO))) {
            out.writeObject(alunos);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Carrega os dados salvos previamente do arquivo
    @SuppressWarnings("unchecked")
    public static void carregarDados() {
        File file = new File(ARQUIVO);
        if (file.exists()) {
            try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(file))) {
                alunos = (List<AlunoAcademia>) in.readObject();
            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
    }
}

