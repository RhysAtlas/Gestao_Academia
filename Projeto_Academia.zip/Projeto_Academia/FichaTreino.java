package Projeto_Academia;

import java.io.Serializable;
/**
 * Representa a ficha de treino de um aluno.
 */

public class FichaTreino implements Serializable {
    private String objetivo;
    private String descricao;

    public FichaTreino(String objetivo, String descricao) {
        this.objetivo = objetivo;
        this.descricao = descricao;
    }

    public String getObjetivo() { return objetivo; }
    public String getDescricao() { return descricao; }

    // Retorna os dados formatados da ficha
    @Override
    public String toString() {
        return "Objetivo: " + objetivo + "\nDescrição: " + descricao;
    }
}

